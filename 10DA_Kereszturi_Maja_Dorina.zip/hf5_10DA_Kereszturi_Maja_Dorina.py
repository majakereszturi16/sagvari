import math

with open('input.txt', 'r') as f:
 lines = f.readlines()

tomb = []

for line in lines:
 szamok = line.split('!')
 for i in range(len(szamok)):
  szamok[i] = int(szamok[i])
 tomb.append(szamok)

# print( tomb )

# 2. feladat: Határozza meg az 1. sorban szereplő páratlan számok összegét!

osszeg = 0
for szam in tomb[ 0 ]:
 if szam % 2 != 0:
  osszeg += szam

print( "Az 1. sorban szereplő páratlan számok összege: ", osszeg )

# 3. feladat: Határozza meg a 2. sorban szereplő 10 legnagyobb szám szorzatának nagyságrendjét!

# rendezzük a tömböt csökkenő sorrendbe
tomb[ 1 ].sort( reverse=True )

# az első 10 elem szorzata
szorzat = 1
for i in range(10):
 szorzat *= tomb[ 1 ][i]

# határozzuk meg a szorzat nagyságrendjét (hányadik hatványra kell emelni a 10-et)
nagysagrend = int(math.log10(szorzat))

print( "A 2. sorban lévő 10 legnagyobb szám szorzatának nagyságrendje: 10^{}".format(nagysagrend) )

# 4. feladat: Határozza meg a 3. sorban szereplő 27-nél nagyobb számok maximumát!

nagyobbak = []

# 27-nél nagyobb számok kiválogatása
for szam in tomb[ 2 ]:
 if szam > 27:
  nagyobbak.append( szam )

# maximum meghatározása
maximum = max(nagyobbak)

print( "A 3. sorban lévő 27-nél nagyobb számok maximuma:", maximum )

# 5. feladat: Határozza meg a 4. sorban szereplő 15 legkisebb szám négyzeteinek összegét!

# rendezzük növekvő sorrendbe a tömb elemeit
tomb[ 3 ].sort()

# 
osszeg = 0
for i in range(15):
 osszeg += ( tomb[ 3 ][ i ] * tomb[ 3 ][ i ] )

print( "A 4. sorban lévő 15 legkisebb szám négyzeteinek összege:", osszeg )

# 6. feladat: Határozza meg az 5. sorban szereplő páros számok számtani közepét (átlagát)!

paros_szamok_osszege = 0
paros_szamok_darab = 0

# összeadjuk a számokat és megszámoljuk, hogy hány darab páros szám van
for szam in tomb[ 4 ]:
 if szam % 2 == 0:
  paros_szamok_osszege += szam
  paros_szamok_darab += 1

# kiszámoljuk az összeget
atlag = paros_szamok_osszege / paros_szamok_darab

print( "Az 5. sorban lévő páros számok átlaga: {:.2f}".format( atlag ) )

# 7. feladat: Határozza meg az összes számra a hárommal osztható számok minimumát!

harommal = []

for sorok in range( len( tomb ) ):
 for szam in tomb[ sorok ]:
  if szam % 3 == 0:
   harommal.append( szam )

print( "A összes hárommal osztható szám minimuma:", min( harommal ) );

